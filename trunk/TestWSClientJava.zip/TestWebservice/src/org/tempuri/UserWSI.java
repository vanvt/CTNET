/**
 * UserWSI.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri;

public class UserWSI  implements java.io.Serializable {
    private org.tempuri.ATSMUser ATSMUser;

    private java.lang.String isWsiError;

    private java.lang.Object[] wsiError;

    private java.lang.String mode;

    public UserWSI() {
    }

    public UserWSI(
           org.tempuri.ATSMUser ATSMUser,
           java.lang.String isWsiError,
           java.lang.Object[] wsiError,
           java.lang.String mode) {
           this.ATSMUser = ATSMUser;
           this.isWsiError = isWsiError;
           this.wsiError = wsiError;
           this.mode = mode;
    }


    /**
     * Gets the ATSMUser value for this UserWSI.
     * 
     * @return ATSMUser
     */
    public org.tempuri.ATSMUser getATSMUser() {
        return ATSMUser;
    }


    /**
     * Sets the ATSMUser value for this UserWSI.
     * 
     * @param ATSMUser
     */
    public void setATSMUser(org.tempuri.ATSMUser ATSMUser) {
        this.ATSMUser = ATSMUser;
    }


    /**
     * Gets the isWsiError value for this UserWSI.
     * 
     * @return isWsiError
     */
    public java.lang.String getIsWsiError() {
        return isWsiError;
    }


    /**
     * Sets the isWsiError value for this UserWSI.
     * 
     * @param isWsiError
     */
    public void setIsWsiError(java.lang.String isWsiError) {
        this.isWsiError = isWsiError;
    }


    /**
     * Gets the wsiError value for this UserWSI.
     * 
     * @return wsiError
     */
    public java.lang.Object[] getWsiError() {
        return wsiError;
    }


    /**
     * Sets the wsiError value for this UserWSI.
     * 
     * @param wsiError
     */
    public void setWsiError(java.lang.Object[] wsiError) {
        this.wsiError = wsiError;
    }


    /**
     * Gets the mode value for this UserWSI.
     * 
     * @return mode
     */
    public java.lang.String getMode() {
        return mode;
    }


    /**
     * Sets the mode value for this UserWSI.
     * 
     * @param mode
     */
    public void setMode(java.lang.String mode) {
        this.mode = mode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UserWSI)) return false;
        UserWSI other = (UserWSI) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ATSMUser==null && other.getATSMUser()==null) || 
             (this.ATSMUser!=null &&
              this.ATSMUser.equals(other.getATSMUser()))) &&
            ((this.isWsiError==null && other.getIsWsiError()==null) || 
             (this.isWsiError!=null &&
              this.isWsiError.equals(other.getIsWsiError()))) &&
            ((this.wsiError==null && other.getWsiError()==null) || 
             (this.wsiError!=null &&
              java.util.Arrays.equals(this.wsiError, other.getWsiError()))) &&
            ((this.mode==null && other.getMode()==null) || 
             (this.mode!=null &&
              this.mode.equals(other.getMode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getATSMUser() != null) {
            _hashCode += getATSMUser().hashCode();
        }
        if (getIsWsiError() != null) {
            _hashCode += getIsWsiError().hashCode();
        }
        if (getWsiError() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWsiError());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWsiError(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMode() != null) {
            _hashCode += getMode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UserWSI.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "UserWSI"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ATSMUser");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ATSMUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "ATSMUser"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isWsiError");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "IsWsiError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wsiError");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "WsiError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tempuri.org/", "anyType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Mode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
