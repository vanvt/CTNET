package org.tempuri;

public class UserWSSoapProxy implements org.tempuri.UserWSSoap {
  private String _endpoint = null;
  private org.tempuri.UserWSSoap userWSSoap = null;
  
  public UserWSSoapProxy() {
    _initUserWSSoapProxy();
  }
  
  public UserWSSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initUserWSSoapProxy();
  }
  
  private void _initUserWSSoapProxy() {
    try {
      userWSSoap = (new org.tempuri.UserWSLocator()).getUserWSSoap();
      if (userWSSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)userWSSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)userWSSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (userWSSoap != null)
      ((javax.xml.rpc.Stub)userWSSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public org.tempuri.UserWSSoap getUserWSSoap() {
    if (userWSSoap == null)
      _initUserWSSoapProxy();
    return userWSSoap;
  }
  
  public org.tempuri.UserWSI callService(org.tempuri.UserWSI wsi) throws java.rmi.RemoteException{
    if (userWSSoap == null)
      _initUserWSSoapProxy();
    return userWSSoap.callService(wsi);
  }
  
  
}