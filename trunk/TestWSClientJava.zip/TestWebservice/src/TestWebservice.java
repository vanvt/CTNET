import java.rmi.RemoteException;
import java.util.Scanner;

import javax.xml.rpc.ServiceException;

import org.tempuri.ATSMUser;
import org.tempuri.CallService;
import org.tempuri.UserWS;
import org.tempuri.UserWSI;
import org.tempuri.UserWSLocator;
import org.tempuri.UserWSSoap;
import org.tempuri.UserWSSoapStub;


public class TestWebservice {
	public static void main(String[] args) {
		UserWSI wsi = new UserWSI();
		ATSMUser user = new ATSMUser(5, "23456");
		wsi.setATSMUser(user);
		wsi.setMode("SAV");
		UserWSLocator WS = new UserWSLocator();
		try {
			wsi = WS.getUserWSSoap().callService(wsi);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(wsi.getATSMUser().getId());
	}
}
